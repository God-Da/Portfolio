
  # Web Developer Portfolio

  This is a code bundle for Web Developer Portfolio. The original project is available at https://www.figma.com/design/EHShXTG9O5CdPrunG4cDQL/Web-Developer-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  